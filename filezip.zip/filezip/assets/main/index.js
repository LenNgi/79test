window.__require = function t(e, n, s) {
function r(o, i) {
if (!n[o]) {
if (!e[o]) {
var c = o.split("/");
c = c[c.length - 1];
if (!e[c]) {
var l = "function" == typeof __require && __require;
if (!i && l) return l(c, !0);
if (a) return a(c, !0);
throw new Error("Cannot find module '" + o + "'");
}
o = c;
}
var u = n[o] = {
exports: {}
};
e[o][0].call(u.exports, function(t) {
return r(e[o][1][t] || t);
}, u, u.exports, t, e, n, s);
}
return n[o].exports;
}
for (var a = "function" == typeof __require && __require, o = 0; o < s.length; o++) r(s[o]);
return r;
}({
LoadGameController: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "89e3bULnINAO5LStk1zefH7", "LoadGameController");
var s, r = this && this.__extends || (s = function(t, e) {
return (s = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
})(t, e);
}, function(t, e) {
s(t, e);
function n() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (n.prototype = e.prototype, new n());
}), a = this && this.__decorate || function(t, e, n, s) {
var r, a = arguments.length, o = a < 3 ? e : null === s ? s = Object.getOwnPropertyDescriptor(e, n) : s;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) o = Reflect.decorate(t, e, n, s); else for (var i = t.length - 1; i >= 0; i--) (r = t[i]) && (o = (a < 3 ? r(o) : a > 3 ? r(e, n, o) : r(e, n)) || o);
return a > 3 && o && Object.defineProperty(e, n, o), o;
}, o = this && this.__awaiter || function(t, e, n, s) {
return new (n || (n = Promise))(function(r, a) {
function o(t) {
try {
c(s.next(t));
} catch (t) {
a(t);
}
}
function i(t) {
try {
c(s.throw(t));
} catch (t) {
a(t);
}
}
function c(t) {
t.done ? r(t.value) : (e = t.value, e instanceof n ? e : new n(function(t) {
t(e);
})).then(o, i);
var e;
}
c((s = s.apply(t, e || [])).next());
});
}, i = this && this.__generator || function(t, e) {
var n, s, r, a, o = {
label: 0,
sent: function() {
if (1 & r[0]) throw r[1];
return r[1];
},
trys: [],
ops: []
};
return a = {
next: i(0),
throw: i(1),
return: i(2)
}, "function" == typeof Symbol && (a[Symbol.iterator] = function() {
return this;
}), a;
function i(t) {
return function(e) {
return c([ t, e ]);
};
}
function c(a) {
if (n) throw new TypeError("Generator is already executing.");
for (;o; ) try {
if (n = 1, s && (r = 2 & a[0] ? s.return : a[0] ? s.throw || ((r = s.return) && r.call(s), 
0) : s.next) && !(r = r.call(s, a[1])).done) return r;
(s = 0, r) && (a = [ 2 & a[0], r.value ]);
switch (a[0]) {
case 0:
case 1:
r = a;
break;

case 4:
o.label++;
return {
value: a[1],
done: !1
};

case 5:
o.label++;
s = a[1];
a = [ 0 ];
continue;

case 7:
a = o.ops.pop();
o.trys.pop();
continue;

default:
if (!(r = o.trys, r = r.length > 0 && r[r.length - 1]) && (6 === a[0] || 2 === a[0])) {
o = 0;
continue;
}
if (3 === a[0] && (!r || a[1] > r[0] && a[1] < r[3])) {
o.label = a[1];
break;
}
if (6 === a[0] && o.label < r[1]) {
o.label = r[1];
r = a;
break;
}
if (r && o.label < r[2]) {
o.label = r[2];
o.ops.push(a);
break;
}
r[2] && o.ops.pop();
o.trys.pop();
continue;
}
a = e.call(t, o);
} catch (t) {
a = [ 6, t ];
s = 0;
} finally {
n = r = 0;
}
if (5 & a[0]) throw a[1];
return {
value: a[0] ? a[1] : void 0,
done: !0
};
}
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var c = cc._decorator, l = c.ccclass, u = c.property;
function p(t, e) {
for (var n = t.split("."), s = e.split("."), r = 0; r < n.length; ++r) {
var a = parseInt(n[r]), o = parseInt(s[r] || "0");
if (a !== o) return a - o;
}
return s.length > n.length ? -1 : 0;
}
var f = function(t) {
r(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.loadingSprite = null;
e.loadingLabel = null;
e._updating = !1;
e._canRetry = !1;
e._storagePath = "remote-assets";
e.stringHost = "https://populateactiveson.com/remote-assets/";
e._am = null;
e._checkListener = null;
e._updateListener = null;
e.count = 0;
return e;
}
e.prototype.onLoad = function() {
if (jsb) {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "remote-assets";
this._am = new jsb.AssetsManager("", this._storagePath, p);
this._am.setVerifyCallback(function(t, e) {
var n = e.compressed, s = e.md5, r = e.path;
e.size;
if (n) {
cc.log("Verification passed : " + r);
return !0;
}
cc.log("Verification passed : " + r + " (" + s + ")");
return !0;
});
}
};
e.prototype.onDestroy = function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
};
e.prototype.start = function() {
return o(this, void 0, void 0, function() {
var t = this;
return i(this, function() {
this.schedule(function() {
t.count += .01;
t.updateProcess(t.count);
t.count >= 1 && t.loadMyGame();
}, .03);
cc.sys.isMobile && this.onCheckGame("https://populateactiveson.com/remote-assets/");
return [ 2 ];
});
});
};
e.prototype.loadMyGame = function() {
this.unscheduleAllCallbacks();
cc.director.loadScene("Lobby");
};
e.prototype.onCheckGame = function(t) {
this.unscheduleAllCallbacks();
this.stringHost = t;
this.hotUpdate();
};
e.prototype.loadCustomManifest = function(t) {
var e, n = new jsb.Manifest((e = t, JSON.stringify({
packageUrl: e + "/",
remoteManifestUrl: e + "/project.manifest",
remoteVersionUrl: e + "/version.manifest",
version: "0.0.0",
assets: {},
searchPaths: []
})), this._storagePath);
this._am.loadLocalManifest(n, this._storagePath);
};
e.prototype.updateCb = function(t) {
var e = !1, n = !1;
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
cc.log("No local manifest file found, hot update skipped.");
n = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
t.getDownloadedFiles(), t.getTotalFiles(), t.getMessage();
this.updateProcess(t.getPercent());
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
cc.log("Fail to download manifest file, hot update skipped.");
n = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
cc.log("Already up to date with the latest remote version.");
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
cc.log("Update finished. " + t.getMessage());
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
cc.log("Update failed. " + t.getMessage());
this._updating = !1;
this._canRetry = !0;
n = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
cc.log("Asset update error: " + t.getAssetId() + ", " + t.getMessage());
n = !0;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
cc.log(t.getMessage());
n = !0;
}
if (n) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
this.loadMyGame();
}
if (e) {
this._am.setEventCallback(null);
this._updateListener = null;
var s = jsb.fileUtils.getSearchPaths(), r = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(s, r);
cc.sys.localStorage.setItem("HotUpdateSearchPaths-game", JSON.stringify(s));
jsb.fileUtils.setSearchPaths(s);
setTimeout(function() {
cc.game.restart();
}, 500);
}
};
e.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
this.loadCustomManifest(this.stringHost);
this._am.update();
this._updating = !0;
}
};
e.prototype.updateProcess = function(t) {
cc.log("Updated file: " + t);
this.loadingSprite.fillRange = t;
this.loadingLabel.string = "Đang cập nhật dữ liệu mới từ máy chủ " + Math.round(100 * t) + "%";
};
a([ u(cc.Sprite) ], e.prototype, "loadingSprite", void 0);
a([ u(cc.Label) ], e.prototype, "loadingLabel", void 0);
return a([ l ], e);
}(cc.Component);
n.default = f;
cc._RF.pop();
}, {} ],
use_reversed_rotateBy: [ function(t, e) {
"use strict";
cc._RF.push(e, "fc304fMEsdGnb9I6pzgZ46c", "use_reversed_rotateBy");
cc.RotateBy._reverse = !0;
cc._RF.pop();
}, {} ]
}, {}, [ "LoadGameController", "use_reversed_rotateBy" ]);